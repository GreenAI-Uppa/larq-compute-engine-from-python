This directory contains files required to build Bazel's website.

The website is built using Jekyll running inside a Docker container.
See the [`Dockerfile`](https://github.com/bazelbuild/bazel/blob/HEAD/scripts/docs/Dockerfile) for instructions how to test this on your local machine.
